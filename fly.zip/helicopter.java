package fly;

public abstract class helicopter implements plane, takeoff {
	
	public void verticaltakeoff() {
		
	}
	public void subsonicfly() {
    }
}
