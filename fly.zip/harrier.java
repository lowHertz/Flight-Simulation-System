package fly;

public abstract class harrier implements plane, takeoff {
	
	public void verticaltakeoff() {
		
	}
	public void subsonicfly() {
    }


}
