package fly;

public interface takeoff {
    
	public void subsonicfly();
		
	public void supersonicfly();

}
