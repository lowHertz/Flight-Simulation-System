package fly;

public interface plane {
	
    public void verticaltakeoff();
		
	public void longdistancetakeoff();

}
