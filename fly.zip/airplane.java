package fly;

public abstract class airplane implements plane, takeoff {
	
	public void verticaltakeoff() {
		
	}
	public void supersonicfly() {
    }

	

}
