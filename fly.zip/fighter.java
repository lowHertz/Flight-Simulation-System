package fly;

public abstract class fighter implements plane, takeoff {
	
	public void longdistancetakeoff() {
		
	}
	public void supersonicfly() {
    }


}
